module.exports = {
  semi: true,
  trailingComma: 'none',
  singleQuote: true,
  tabWidth: 2,
  useTabs: false,
  bracketSpacing: true,
  arrowParens: 'avoid',
  proseWrap: 'preserve',
  jsxBracketSameLine: true,
  printWidth: 120,
  endOfLine: 'auto'
};
