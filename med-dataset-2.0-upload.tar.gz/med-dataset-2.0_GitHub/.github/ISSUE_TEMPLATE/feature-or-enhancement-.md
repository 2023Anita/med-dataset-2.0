---
name: 'Feature or enhancement '
about: Suggest an idea for this project
title: '[Feature]'
labels: enhancement
assignees: ''
---

**你的功能请求是否与某个问题相关？请描述。**
清晰、简洁地描述一下存在的问题是什么。例如：当我[具体情况]时，我总是感到很沮丧。

**描述你期望的解决方案**
清晰、简洁地描述你希望实现的情况。

**描述你考虑过的替代方案**
清晰、简洁地描述你所考虑过的任何其他解决方案或功能。

**其他相关信息**
在此处添加与该功能请求相关的其他任何背景信息或截图。
